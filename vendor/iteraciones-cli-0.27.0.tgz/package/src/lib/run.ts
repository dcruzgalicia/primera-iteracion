import { cpus } from 'node:os';
import { logWarning } from './logger.js';
import { recordScriptExec } from './script-recorder.js';

export interface RunResult {
  stdout: string;
  stderr: string;
  exitCode: number;
}

interface RunOptions {
  cwd?: string;
  timeoutMs?: number;
  input?: string;
  env?: Record<string, string>;
  onSpawn?: (pid: number) => void;

  scriptKey?: string;

  inputTarget?: string;
}

export class ProcessSpawnError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ProcessSpawnError';
  }
}

export class ProcessTimeoutError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ProcessTimeoutError';
  }
}

const inFlightPids = new Set<number>();

function killGroups(signal: NodeJS.Signals): void {
  for (const pid of inFlightPids) {
    try {
      process.kill(-pid, signal);
    } catch {}
  }
}

export function forwardSignalsToChildren(): void {
  for (const signal of ['SIGINT', 'SIGTERM'] as const) {
    const handler = () => {
      killGroups(signal);
      if (process.listenerCount(signal) > 1) return;
      process.off(signal, handler);
      process.kill(process.pid, signal);
    };
    process.on(signal, handler);
  }
}

export async function killProcessTree(rootPid: number): Promise<void> {
  try {
    process.kill(-rootPid, 'SIGKILL');
  } catch {
    try {
      process.kill(rootPid, 'SIGKILL');
    } catch {}
  }
}

type Spawned = Bun.Subprocess<'pipe' | 'ignore', 'pipe', 'pipe'>;

export async function exec(command: string, args: string[], options: RunOptions = {}): Promise<RunResult> {
  let proc: Spawned;

  try {
    proc = Bun.spawn([command, ...args], {
      stdin: options.input !== undefined ? 'pipe' : 'ignore',
      stdout: 'pipe',
      stderr: 'pipe',
      cwd: options.cwd,
      env: options.env ? { ...process.env, ...options.env } : undefined,
      detached: true,
    });
  } catch {
    throw new ProcessSpawnError(`No se encontró el comando "${command}". Verifica que esté instalado y disponible en PATH.`);
  }
  options.onSpawn?.(proc.pid);
  inFlightPids.add(proc.pid);
  try {
    const result = await awaitProcess(command, proc, options);
    if (result.exitCode === 0) recordScriptExec(command, args, options, result.stdout);
    return result;
  } finally {
    inFlightPids.delete(proc.pid);
  }
}

export async function killInFlightProcesses(): Promise<void> {
  const pids = [...inFlightPids];
  await Promise.allSettled(pids.map((pid) => killProcessTree(pid)));
  inFlightPids.clear();
}

async function awaitProcess(command: string, proc: Spawned, options: RunOptions): Promise<RunResult> {
  if (options.input !== undefined) {
    if (proc.stdin == null || typeof proc.stdin === 'number') {
      throw new Error(`No se pudo escribir stdin del comando "${command}".`);
    }
    proc.stdin.write(options.input);
    await proc.stdin.flush();
    proc.stdin.end();
  }

  const outputPromise = Promise.all([new Response(proc.stdout).text(), new Response(proc.stderr).text(), proc.exited]);
  if (options.timeoutMs === undefined) {
    const [stdout, stderr, exitCode] = await outputPromise;
    return { stdout, stderr, exitCode };
  }

  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    void killProcessTree(proc.pid);
  }, options.timeoutMs);
  const [stdout, stderr, exitCode] = await outputPromise;
  clearTimeout(timer);
  if (timedOut) {
    throw new ProcessTimeoutError(
      `el comando "${command}" no terminó en ${Math.round(options.timeoutMs / 1000)}s y fue terminado junto con sus procesos hijos.`,
    );
  }
  return { stdout, stderr, exitCode };
}

export function cpuConcurrency(max: number): number {
  return Math.min(max, Math.max(1, cpus().length));
}

interface MapConcurrencyOptions {
  onCancel?: () => Promise<void> | void;
}

export async function mapWithConcurrency<T, R>(
  items: T[],
  limit: number,
  fn: (item: T) => Promise<R>,
  options: MapConcurrencyOptions = {},
): Promise<R[]> {
  if (!Number.isInteger(limit) || limit < 1) {
    throw new Error(`mapWithConcurrency: limit debe ser un entero >= 1, recibido: ${limit}`);
  }
  const results: R[] = new Array(items.length);
  let nextIndex = 0;
  let aborted = false;
  let firstError: unknown = null;
  let cancelStarted = false;

  const firstFailure = async (err: unknown): Promise<void> => {
    if (firstError !== null) return;
    firstError = err;
    aborted = true;
    if (options.onCancel && !cancelStarted) {
      cancelStarted = true;
      try {
        await options.onCancel();
      } catch (err) {
        logWarning(`no se pudieron limpiar los procesos en vuelo: ${(err as Error).message}`, 'build');
      }
    }
  };

  async function worker(): Promise<void> {
    while (!aborted && nextIndex < items.length) {
      const index = nextIndex++;
      const item = items[index];
      if (item === undefined) throw new Error(`mapWithConcurrency: item ${index} sin definir`);
      try {
        results[index] = await fn(item);
      } catch (err) {
        await firstFailure(err);
        return;
      }
    }
  }

  const workers = Array.from({ length: Math.min(limit, items.length) }, worker);
  await Promise.all(workers);
  if (firstError !== null) throw firstError;
  return results;
}
